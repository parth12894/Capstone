#include "CNC_5AXIS/CNC_5Axis.h"

#define X_DIR1 0x2000000 


char line[5][128] =
{	"G0 X0 Y0 F100",
	"G1 X1 Y0",
	"G1 X1 Y1",
	"G1 X0 Y1",
	"G0 X0 Y0"
};


int main()
{
	atmel_start_init();
	//parser_init();
	//stepper_init();
	//parse_line("M9");
	

	printf("\n\t\t--  PP01 - 3+2 Axis CNC Controller  --\n");
	printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
	
	
	
	
	
	
	
	pwm_enable(&PWM_1);
	
	
	
	//gpio_set_pin_direction(D35, GPIO_DIRECTION_OUT);
	//gpio_set_pin_function(D35, GPIO_PIN_FUNCTION_OFF);
	//gpio_set_pin_level(D35,	false);
	//
	//
	//while(1)
	//{
		//gpio_toggle_pin_level(D35);
		//delay_us(500);
	//}
	
	while(1);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	int i, l = 500;
	
	while(1)
	{	
		for(i=0;i<3;i++)
		{
			l = l + 500;
			pwm_set_parameters(&PWM_1,3000,l,0);
			delay_ms(3000);
		}
		
		for(i=0;i<3;i++)
		{
			l = l - 500;
			pwm_set_parameters(&PWM_1,3000,l,0);		
			delay_ms(3000);	
		}
	}
	
	for(;;);

	//printf("====================Sanity Check=====================\n");
	//uint8_t i;
	//for(i=0;i<5;i++)
	//{
		//printf(">> Command: ");
		//
		//puts(line[i]);
		//parse_line(line[i]);
		//
		//delay_ms(3000);
	//}
	//printf("================Sanity Check Complete================\n");


////////////////////////////////////////////////////////////////////////////////////////////////////
	
	gpio_set_pin_function(Q3, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_direction(Q4, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(Q4, GPIO_PIN_FUNCTION_OFF);
	
	//gpio_set_pin_function(Q5, GPIO_PIN_FUNCTION_OFF);
	//gpio_set_pin_function(Q6, GPIO_PIN_FUNCTION_OFF);
////////////////////////////////////////////////////////////////////////////////////////////////////


	char input[128];
	while(1)
	{
		printf("\n>> ");
		//printf("ok\r\n");
		fgets(input, sizeof(input), stdin);
		printf("%s",input);
		parse_line(input);
		
		#if DEBUG
			printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],parser_input.ijklm[0],parser_input.ijklm[1],parser_input.ijklm[2],parser_input.feedrate);
			printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %f\nPlane: %d %d\nVertical: %d\n\n",parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		#endif
	}
	
	
	for(;;);
	while (1);
	
	return 0;
}



/*

for xyz
1/32 micro stepping -> fastest X step time 15*2 = 30 us
1/16 micro stepping -> fastest X step time 27*2 = 54 us

*/










