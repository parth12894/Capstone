#include "CNC_5AXIS/CNC_5Axis.h"

#define X_DIR1 0x2000000 

char line0[7][128] =
{	"G0 X0 Y0",
	"M3 S10",
	"G4 P3",
	"G1 X30 Y30 F100",
	"G4 P3",
	"G0 X0 Y0",
	"M2"
};


char line[7][128] =
{	"G0 X0 Y0 F100",
	"G1 X1 Y0",
	"G1 X1 Y1",
	"G1 X0 Y1",
	"G0 X0 Y0",
	"G0 X0 Y0",
	"G0 X0 Y0",
};

int main()
{
	atmel_start_init();
	uint8_t i;

	printf("\n\t\t--  PP01 - 5 Axis CNC Controller  --\n");
	printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__); 
	

	//delay_ms(1000);

	
	parser_init();
	serial_init();
	//ISR_init();
	
	i=3;
	
	printf(">> ===============Parse start===============\n");

	for(i=0;i<7;i++)
	{
		
		printf(">> Enter Command: ");
		
		puts(line[i]);
		parse_line(line[i]);
		
		delay_ms(3000);
	}
	
	printf(">> ================Parse end================\n");
	
	
	
	while (1){}
	for(;;);
}








