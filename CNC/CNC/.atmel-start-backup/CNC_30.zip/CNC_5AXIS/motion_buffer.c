#include "CNC_5Axis.h"
#include "stepper.h"

//static motion_block_t motion_buffer[MOTION_BUFFER_SIZE];
static volatile int motion_buffer_head;
static volatile int motion_buffer_tail;


void update_motion_buffer(float* target_pose, float* offset, float feedrate)
{

    uint8_t i;
    uint32_t target_steps[N_AXIS];
	float target_joints[N_AXIS];
	
	// transform target to joint space
	inv_kin_slow(target_joints, target_pose, offset);
	
	
	// Calculate the buffer head after we push this byte
	int next_buffer_head = (motion_buffer_head + 1) % MOTION_BUFFER_SIZE;

	// If the buffer is full; rest here until there is room in the buffer.
	while(motion_buffer_tail == next_buffer_head){};
	
    motion_block_t *block = &motion_buffer[motion_buffer_head];
	block->is_Mcode = 0;
    block->max_step_count = 0;
    block->millimeters = 0;
    block->radians = 0;
	block->feedrate = (int) (FEED_RATE_PARAMETER / feedrate);
	
	#if DEBUG_ISR
		block->bufferhead = motion_buffer_head;
	#endif
	

    //for(i=0;i<N_AXIS;i++)
	//{
        //if (i == 3 || i == 4)
		//{
            //target_steps[i] = lround(target_joints[i]*STEPS_PER_DEGREE) ; 
            //block->steps[i] = target_steps[i];
            //block->radians += square(abs(target_steps[i])/STEPS_PER_DEGREE);
        //}else
		//{
            //target_steps[i] = lround(target_joints[i]*STEPS_PER_MM) ; 
            //block->steps[i] = target_steps[i];
            //block->millimeters += square(abs(target_steps[i])/STEPS_PER_MM);
        //}
    //}
	
	
	
	
	
	
	
	target_steps[X_AXIS] = lround(target_joints[X_AXIS]*STEPS_PER_MM_X);
	block->steps[X_AXIS] = target_steps[X_AXIS];
	block->millimeters += square(abs(target_steps[X_AXIS])/STEPS_PER_MM_X);
	
	target_steps[Y_AXIS] = lround(target_joints[Y_AXIS]*STEPS_PER_MM_Y);
	block->steps[Y_AXIS] = target_steps[Y_AXIS];
	block->millimeters += square(abs(target_steps[Y_AXIS])/STEPS_PER_MM_Y);
	
	target_steps[Z_AXIS] = lround(target_joints[Z_AXIS]*STEPS_PER_MM_Z);
	block->steps[Z_AXIS] = target_steps[Z_AXIS];
	block->millimeters += square(abs(target_steps[Z_AXIS])/STEPS_PER_MM_Z);
	
	target_steps[A_AXIS] = lround(target_joints[A_AXIS]*STEPS_PER_DEGREE) ;
	block->steps[A_AXIS] = target_steps[A_AXIS];
	block->radians += square(abs(target_steps[A_AXIS])/STEPS_PER_DEGREE);
	
	target_steps[C_AXIS] = lround(target_joints[C_AXIS]*STEPS_PER_DEGREE) ;
	block->steps[C_AXIS] = target_steps[C_AXIS];
	block->radians += square(abs(target_steps[C_AXIS])/STEPS_PER_DEGREE);
	
	
	block->millimeters = sqrt(block->millimeters);
	block -> radians = sqrt(block->radians);
	
	#if DEBUG
		printf("Steps: %d %d %d %d %d BufferHead: %d\nMillimeters: %.4f\nRadians: %.4f\n\n",block->steps[X_AXIS],block->steps[Y_AXIS],block->steps[Z_AXIS],block->steps[A_AXIS],block->steps[C_AXIS],motion_buffer_head,block->millimeters,block->radians);
    #endif
	
	printf("\nBufferHead: %d\n",motion_buffer_head);
	
	
	for(i=0;i<N_AXIS;i++)
	{
		if((int)(block->steps[i]) < 0)
		{
			block->steps[i] = abs(block->steps[i]);
			block->dir[i] = 0;
		}
		else
			block->dir[i] = 1;		
		block->max_step_count = max(block->max_step_count,block->steps[i]);
	}    

	motion_buffer_head = next_buffer_head;
	
	#if RUN_MOTORS
		ISR_EN();
	#endif
}


void add_M_block(uint8_t code, uint32_t speed, uint32_t parameter)
{
	int next_buffer_head = (motion_buffer_head + 1) % MOTION_BUFFER_SIZE;

	// If the buffer is full; rest here until there is room in the buffer.
	while(motion_buffer_tail == next_buffer_head){};
	
	motion_block_t *block = &motion_buffer[motion_buffer_head];
	
	//add m parameters to the motion block
	block->is_Mcode = 1;
	block->code = code;
	block->speed = speed;
	block->parameter = parameter;
	
	#if DEBUG_ISR
		block->bufferhead = motion_buffer_head;
	#endif
	
	
	motion_buffer_head = next_buffer_head;
	
	#if RUN_MOTORS
		ISR_EN();
	#endif
	
}

motion_block_t *get_motion_block(){
    if (motion_buffer_head == motion_buffer_tail) { return(NULL); }
    return(&motion_buffer[motion_buffer_tail]);
}

inline void increment_current_block() {
	if (motion_buffer_head != motion_buffer_tail)
		motion_buffer_tail = (motion_buffer_tail + 1) % MOTION_BUFFER_SIZE;
}

 int get_head() {
	 return motion_buffer_head;
 }

 int get_tail() {
	 return motion_buffer_tail;
 }