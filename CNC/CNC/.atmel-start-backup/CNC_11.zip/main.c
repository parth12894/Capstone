#include <atmel_start.h>


#include <stdio.h>

// SDMMC I/O
#define D33 MCDA2
#define D41	MCDA1
#define D44	MCCK
#define D48	MCDA0
#define D49 MCCDA

// USART for Serial Comm.
#define D46	RX
#define D47	TX

// PWM Outputs
#define D31 PWM0_L0
#define D45 PWM0_H1
#define D36 PWM0_H2
#define D20	PWM0_L3

#define D35 PWM1_H0
#define D43	PWM1_L2

// Analog Outputs
#define A12	DAC0
#define A13	DAC1

// Digital Outputs
#define OUT1	D12
#define ENABLE  D11
#define X_DIR   D10 
#define X_STEP  D8
#define Y_DIR   D7
#define Y_STEP  D6
#define Z_DIR   D3
#define Z_STEP  D2
#define A_DIR   D14
#define A_STEP  D15
#define C_DIR	D16
#define C_STEP  D17


#define xdir X_DIR  
#define xstep X_STEP 
#define ydir Y_DIR  
#define ystep Y_STEP 
#define zdir Z_DIR  
#define zstep Z_STEP 
#define adir A_DIR  
#define astep A_STEP 
#define cdir C_DIR	
#define cstep C_STEP  



// Digital Inputs
#define X_LIM	A0
#define Y_LIM	A1
#define Z_LIM	A2
#define A_LIM	A3
#define C_LIM	A4


// Unused Inputs
#define IN1		A8
#define IN2		A9 
#define IN3		A10
#define IN4		A14
#define IN5		A15

// Unused Outputs
#define OUT2	D13
#define OUT3	D9
#define OUT4	D5
#define OUT5	D18
#define OUT6	D19
#define OUT7	D21
#define OUT8	D22
#define OUT9	D26
#define OUT10	D30
#define OUT11	D52
#define OUT12	D53



int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
	}
}