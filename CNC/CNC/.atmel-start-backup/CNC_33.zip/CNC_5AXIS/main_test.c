#include "CNC_5Axis.h"

#define X_DIR1 0x2000000 


void main_test_filesystem()
{
		printf("-- SD Card Example on FatFs --\n\r");
		printf("-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
		
		printf("Please plug an SD, MMC or SDIO card in slot.\n\r");

		/* Wait card present and ready */
		if (SD_MMC_OK != sd_mmc_check(0))
		{
			printf("Please insert a FAT system SD card . . .\n\r");
			while(SD_MMC_OK != sd_mmc_check(0)){}
		}
		
		
		fatfs_example();

		while (1){};

};

void fast_GPIO_test()
{
	int hw, mask;
	
	mask = 1U << GPIO_PIN(X_DIR);
	printf(">>X_dir mask  %#0x \n", mask);
	hw = (uint32_t)PIOA + 0x3 * 0x200;
	printf(">>X_dir hw %#0x \n", hw);
	
	
	while(1)
	{
		hri_pio_set_ODSR_reg(PIOD, X_DIR1);
		//((Pio *)PIOD)->PIO_SODR = X_DIR1;
		//printf(">>X_dir is set\n");
		
		delay_us(10);
		
		hri_pio_clear_ODSR_reg(PIOD, X_DIR1);
		//((Pio *)PIOD)->PIO_CODR = X_DIR1;
		//printf(">>X_dir is clear\n");
		delay_us(10);
	}
	
}

int main_test_jason ()
{

	#if DEBUG_FILE
	//reset files
	FILE *fp1,*fp2,*fp3,*fp4,*fp5;
	fp1 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\xsegments.txt","w");
	fp2 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\ysegments.txt","w");
	fp3 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\zsegments.txt","w");
	fp4 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\asegments.txt","w");
	fp5 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\cegments.txt","w");
	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
	fclose(fp4);
	fclose(fp5);
	#endif

	char line[128];
	parser_init();
	while(1){
		
		#if DEBUG
		printf("Enter Something: \n");
		#endif
		
		fgets(line, sizeof(line), stdin);
		parse_line(line);
		
		#if DEBUG
		printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",
		parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],
		parser_input.ijk[0],parser_input.ijk[1],parser_input.ijk[2],
		parser_input.feedrate);

		printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %f\nPlane: %d %d\nVertical: %d\n\n",
		parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],
		parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		#endif
	}

	return (EXIT_SUCCESS);
}

uint32_t temp;
uint32_t j = 0;
uint32_t k = 50;

int flag = 0;


/**
 * Example of using TIMER_0.
 */
static struct timer_task TIMER_0_task1, TIMER_0_task2;

static void TIMER_0_task1_cb(const struct timer_task *const timer_task)
{
	gpio_set_pin_level(DGI_GPIO0,HIGH);
	gpio_set_pin_level(C_STEP, true);

	j = (j + 1) % (10*25600);
	
	if(j==0)
	{
		
		//if(k <= 50)
			//flag = 1;
		//
		//if(k >= 100)
			//flag = 0;
		
			
		if(flag == 0)
		{	
			k = 35;
			flag = 1;
		}
		else
		{
			k = 200;
			flag = 0;
		}
			
		temp = (k * 19);
		//printf(">> %d\n", temp);
		timer_set_clock_cycles_per_tick(&TIMER_0,temp);
	}
	timer_add_task(&TIMER_1, &TIMER_0_task2);
}

static void TIMER_0_task2_cb(const struct timer_task *const timer_task)
{
	gpio_set_pin_level(DGI_GPIO0,LOW);
	gpio_set_pin_level(C_STEP, false);
}

void TIMER_0_ex(void)
{
	TIMER_0_task1.interval = 1;
	TIMER_0_task1.cb       = TIMER_0_task1_cb;
	TIMER_0_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_0_task2.interval = 1;
	TIMER_0_task2.cb       = TIMER_0_task2_cb;
	TIMER_0_task2.mode     = TIMER_TASK_ONE_SHOT;

	timer_add_task(&TIMER_0, &TIMER_0_task1);
	timer_start(&TIMER_0);
}

int main_test_dual_timers()
{
	atmel_start_init();
	
	flag = 0;
	
	printf("\n\t\t--  PP01 - 3+2 Axis CNC Controller  --\n");
	printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__);

	stepper_init();
	TIMER_0_ex();
	
	int i;
	for (i=0;i<60;i++)
		delay_ms(3000);
	
	printf("\n---Done---\n");
	
	timer_stop(&TIMER_0);
	
	for(;;);
	
	return 0;
};

void parser(void)
{
	char str [256];
	char delim[] = " ";
	
	while (1)
	{
		printf ("Insert a g-code... ");
		gets (str);
		printf ("\nDecoding command: %s\n\n",str);
		
		char *ptr = strtok(str, delim);
		
		while(ptr != NULL)
		{
			printf("%s", ptr);
			
			if(strcmp(ptr, "G0") == 0)
			printf(": Rapid Linear Motion");
			else if(strcmp(ptr, "G1") == 0)
			printf(": Linear interpolation");
			else if(ptr[0] == 'F')
			printf(": Change feed rate");
			else if(ptr[0] == 'X')
			printf(": Move X axis");
			else if(ptr[0] == 'Y')
			printf(": Move Y axis");
			else if(ptr[0] == 'Z')
			printf(": Move Z axis");
			else if(strcmp(ptr, "M3") == 0)
			printf(": Turn on spindle");
			else if(strcmp(ptr, "M5") == 0)
			printf(": Turn off spindle");
			else
			printf(": Unknown word");
			
			
			
			printf("\n");
			ptr = strtok(NULL, delim);
		}
		
		printf("\n");
		printf("\n");
	}
}

int main_pwm_test()
{
	atmel_start_init();
	parser_init();
	stepper_init();
	parse_line("M9");
	

	printf("\n\t\t--  PP01 - 3+2 Axis CNC Controller  --\n");
	printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
	
	
	pwm_enable(&PWM_1);
	pwm_set_parameters(&PWM_1,PWM_PERIOD,886,0);
	for(;;);
	
	
	for(;;)
	{
		printf(">> dddd\n");
		
		pwm_set_parameters(&PWM_1,PWM_PERIOD,PWM_PERIOD-100,0);
		printf(">> ddddd\n");
		delay_ms(5000);
		pwm_set_parameters(&PWM_1,PWM_PERIOD,100,0);
		delay_ms(5000);
		
	}
	
	int i, l = 2000;
	
	while(1)
	{
		
		l = l+ 20;
		pwm_set_parameters(&PWM_1,l,1000,0);
		printf(">> %d\n",l);
		delay_ms(3000);

	}
	
	
	while(1)
	{
		for(i=0;i<12;i++)
		{
			l = l + 100;
			pwm_set_parameters(&PWM_1,2000,l,0);
			
		}
		
		for(i=0;i<12;i++)
		{
			l = l - 100;
			pwm_set_parameters(&PWM_1,2000,l,0);
			delay_ms(3000);
		}
	}
	
	for(;;);
	
	return 0;
}