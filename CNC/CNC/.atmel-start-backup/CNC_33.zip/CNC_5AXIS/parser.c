#include "CNC_5Axis.h"

parser_input_t parser_input;
parser_state_t parser_state;

void parser_init()
{
    memset(&parser_state,0,sizeof(parser_state_t));
	memset(&parser_input,0,sizeof(parser_input_t));
	
    parser_state.plane[0] = X_AXIS;
    parser_state.plane[1] = Y_AXIS; // Default XY Plane
    parser_state.axis_linear = Z_AXIS; 
	
	parser_state.multiplier = 1;
	parser_state.abs_or_inc = ABS_MODE;
	parser_state.feedrate = 500;

}

/* 3-part interpreter
1. parsing
2. error checking
3. execution
*/

// parsing
void parse_line(char *line)
{
    uint8_t command = 255; // integer indicates G command i.e. 2 -> G2
	uint8_t is_G_or_M_code = 255;
    uint8_t char_counter;
    char letter;
	
	char_counter = 1;
	command = (int)get_float_after_letter(line,&char_counter);
	char_counter = 0;
	
	if(line[0] == ';')
		return;	
	else if(line[0] =='G')
		is_G_or_M_code = GCODE;
	else if(line[0] =='M')
		is_G_or_M_code = MCODE;
	else if(line[0] =='$')
	{
		execute_from_sd_card(command);
		return;
	}
	else if(line[0] =='*')
	{
		sanity_check();
		return;
	}	
	else
	{	
		printf("ERROR: Not a G or M Command\n%s \n",line); 
		return;
	}
	
	
	
	// 0-terminated line
    while(line[char_counter] != 0)				
	{ 
        char_counter++;
        letter = line[char_counter];

        // Once command is set, get parameter values
        switch(letter)
		{
            case 'X':
                char_counter++;
                parser_input.xyzac[X_AXIS] = parser_state.multiplier * get_float_after_letter(line,&char_counter);
				if(parser_state.abs_or_inc == INC_MODE) parser_input.xyzac[X_AXIS] = parser_state.position[X_AXIS] + parser_input.xyzac[X_AXIS];

				break;
            case 'Y':
                char_counter++;
                parser_input.xyzac[Y_AXIS] = parser_state.multiplier * get_float_after_letter(line,&char_counter);
				if(parser_state.abs_or_inc == INC_MODE) parser_input.xyzac[Y_AXIS] = parser_state.position[Y_AXIS] + parser_input.xyzac[Y_AXIS];
				break;
            case 'Z':
                char_counter++;
                parser_input.xyzac[Z_AXIS] = parser_state.multiplier * get_float_after_letter(line,&char_counter);
				if(parser_state.abs_or_inc == INC_MODE) parser_input.xyzac[Z_AXIS] = parser_state.position[Z_AXIS] + parser_input.xyzac[Z_AXIS];
				break;
            case 'A':
                char_counter++;
                parser_input.xyzac[A_AXIS] = get_float_after_letter(line,&char_counter);
				if(parser_state.abs_or_inc == INC_MODE) parser_input.xyzac[A_AXIS] = parser_state.position[A_AXIS] + parser_input.xyzac[A_AXIS];
				break;
            case 'C':
                char_counter++;
                parser_input.xyzac[C_AXIS] = get_float_after_letter(line,&char_counter);
				if(parser_state.abs_or_inc == INC_MODE) parser_input.xyzac[C_AXIS] = parser_state.position[C_AXIS] + parser_input.xyzac[C_AXIS];
				break;
            case 'I':
                char_counter++;
                parser_input.ijk[X_AXIS] = parser_state.multiplier * get_float_after_letter(line,&char_counter);
				break;
            case 'J':
                char_counter++;
                parser_input.ijk[Y_AXIS] = parser_state.multiplier * get_float_after_letter(line,&char_counter);
				break;
            case 'K':
                char_counter++;
                parser_input.ijk[Z_AXIS] = parser_state.multiplier * get_float_after_letter(line,&char_counter);
				break;
            case 'F':
                char_counter++;
                parser_input.feedrate = (parser_state.multiplier * get_float_after_letter(line,&char_counter));
				
				if(parser_input.feedrate < MAX_FEEDRATE)
					parser_state.feedrate = parser_input.feedrate;
				else
					parser_state.feedrate = MAX_FEEDRATE;
				break;
			case 'P':
				char_counter++;
				parser_input.p = get_float_after_letter(line,&char_counter);
				break;
			case 'S':
				char_counter++;
				parser_input.s = get_float_after_letter(line,&char_counter);
				break;
        }
    } 
    
	
	// Reserved for future error checking

    // Execution
    float input_relative[N_AXIS];
    int i;

	
    if (is_G_or_M_code == GCODE)
	{
		switch(command)
		{
			case 0:
				#if DEBUG
					printf("RAPID LINEAR MOVE\n");
				#endif
				add_linear_motion(parser_input.xyzac, parser_state.position,MAX_FEEDRATE);
				memcpy(parser_state.position,parser_input.xyzac,N_AXIS*sizeof(float));
				// ADD Code to indicate rapid move
				break;
			case 1:
				#if DEBUG
					printf("LINEAR MOVE\n");
				#endif
				add_linear_motion(parser_input.xyzac, parser_state.position,parser_state.feedrate);
				memcpy(parser_state.position,parser_input.xyzac,N_AXIS*sizeof(float));
				break;
			case 2:
				/* The target input is relative to the position. So we need to convert the absolute G command arguments
					to relative.*/
				for (i=0;i<N_AXIS;i++)
					input_relative[i] = parser_input.xyzac[i] - parser_state.position[i];
	
				#if DEBUG
					printf("CURVE/HELICAL MOVE CW\n");
					printf("relative position: %f %f %f %f %f\n\n", input_relative[X_AXIS],input_relative[Y_AXIS],input_relative[Z_AXIS],
						input_relative[A_AXIS],input_relative[C_AXIS]);
				#endif
	
				add_arc_motion(parser_state.position,input_relative,parser_input.ijk,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear,1,parser_state.feedrate);
				break;
			case 3:
				for (i=0;i<N_AXIS;i++)
					input_relative[i] = parser_input.xyzac[i] - parser_state.position[i];
	
				#if DEBUG
					printf("CURVE/HELICAL MOVE CCW\n");
					printf("relative position: %f %f %f %f %f\n\n", input_relative[X_AXIS],input_relative[Y_AXIS],input_relative[Z_AXIS],
						input_relative[A_AXIS],input_relative[C_AXIS]);
				#endif
	
				add_arc_motion(parser_state.position,input_relative,parser_input.ijk,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear,0,parser_state.feedrate);
				break;
			case 4:
				#if DEBUG
					printf("DWELLING\n");
				#endif
					add_M_block(100,parser_input.s,parser_input.p);
				break;
			case 17:
				#if DEBUG
					printf("Plane: XY\n");
				#endif
				parser_state.plane[0] = X_AXIS;
				parser_state.plane[1] = Y_AXIS;
				parser_state.axis_linear = Z_AXIS;
				break;
			case 18:
				#if DEBUG
					printf("Plane: XZ\n");
				#endif
				parser_state.plane[0] = X_AXIS;
				parser_state.plane[1] = Z_AXIS;
				parser_state.axis_linear = Y_AXIS;
				break;
			case 19:
				#if DEBUG
					printf("Plane: YZ\n");
				#endif
				parser_state.plane[0] = Y_AXIS;
				parser_state.plane[1] = Z_AXIS;
				parser_state.axis_linear = X_AXIS;
				break;
			case 20:
				#if DEBUG
					printf("Programing in Inches\n");
				#endif
				parser_state.multiplier = INCHES_PER_MM;
				break;
			case 21:
				#if DEBUG
					printf("Programing in Millimeters \n");
				#endif
				parser_state.multiplier = 1;
				break;
			case 28:
				#if DEBUG
					printf("Go To machine Zero\n");
				#endif
				parse_line("G0 X0 Y0 Z0 A0 C0");
				break;
			case 90:
				#if DEBUG
					printf("Programing in Absolute mode \n");
				#endif
				parser_state.abs_or_inc = ABS_MODE;
				break;
			case 91:
				#if DEBUG
					printf("Programing in Incremental mode \n");
				#endif
				parser_state.abs_or_inc = INC_MODE;
				break;	
				
			case 92:
				#if DEBUG
					printf("Setting current position as machine ZERO\n");
				#endif
				memset(&parser_input,0,sizeof(parser_input_t));
				memcpy(parser_state.position,parser_input.xyzac,N_AXIS*sizeof(float));
				break;
			default:
				printf("This G-code not supported!\n");
				return;
				break;	
		}
		
		return;
	} 
	else
	{
		switch(command)
		{
			case 0:
				#if DEBUG
					printf("Machine STOP\n");
				#endif
				break;
			case 2:
				#if DEBUG
					printf("End Program\n");
				#endif
				break;
			case 3:
			case 4:
				#if DEBUG
					printf("Spindle ON Speed:%d\n", parser_input.s);
				#endif
				break;
			case 5:
				#if DEBUG
					printf("Spindle OFF\n");
				#endif
				break;
			case 7:
				#if DEBUG
					printf("Mist Coolant ON\n");
				#endif
				break;
			case 8:
				#if DEBUG
					printf("Flood Coolant ON\n");
				#endif
				break;
			case 9:
				#if DEBUG
					printf("Coolant OFF\n");
				#endif
				break;
			default:
				printf("This code not supported!\n");
				return;
				break;
		}
		
		add_M_block(command,parser_input.s,parser_input.p);
		
		return;
	}
}




/*

G0 = Fast Linear Move
G1 = Linear Move
G2 = Arc clockwise
G3 = Arc counter-clockwise
G4 = Dwell For P seconds
G17 = Select plane XY
G18 = Select plane XZ
G19 = Select plane YZ
G20 = Programing in Inches
G21 = Programing in Millimeters
G90 = Programing in Absolute mode
G91 = Programing in Incremental mode
G92 = Set current position as machine ZERO


M0 = Machine STOP
M2 = End Program
M3 = Spindle ON
M4 = Spindle ON
M5 = Spindle OFF
M7 = Mist Coolant ON
M8 = Flood Coolant ON
M9 = Coolant OFF


X = X axis (in mm/inch)
Y = Y axis (in mm/inch)
Z = Z axis (in mm/inch)
A = A axis (in degrees/rad)
C = C axis (in degrees/rad)
I = X offset
J = Y offset
K = Z offset
F = Feed-rate unit/min
S = Spindle Speed (0-100)
P = Parameter; Used for Dwell indicates seconds


*/