#include "CNC_5Axis.h"

/* Read/write buffer */
static uint8_t data_buffer[DATA_SIZE];


uint8_t execute_from_sd_card(uint8_t file_num)
{

	char read_file_name[12];
	
	
	sprintf(read_file_name,"%d.txt", file_num);
	printf("\nReading from file '%s'", read_file_name);	
	

	static FATFS fs;
	static FIL file_object;
	FRESULT res;
	
	char line[128];
	
	
	/* Wait card present and ready */
	if (SD_MMC_OK != sd_mmc_check(0))
		printf("\nPlease insert a FAT system SD card . . .\n\r");
	
	while(SD_MMC_OK != sd_mmc_check(0));
	
	// Mount Drive
	f_mount(&fs, "", 0);
	delay_ms(1);
	
	/* Open a text file */
	res = f_open(&file_object, (char const *)read_file_name, FA_READ);
	if (res)
	{
		puts("Error Opening File . . .");
		puts("Returning to terminal mode . . . \n");
		return (int)res;
	}
	
	
	puts("\nExecuting from the SD Card . . . ");
	
	while (f_gets(line, sizeof line, &file_object)) 
	{
		printf("\n>> %s", line);

		parse_line(line);
		#if DEBUG
			printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",
				parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],
				parser_input.ijk[0],parser_input.ijk[1],parser_input.ijk[2],
				parser_input.feedrate);
			
			printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %f\nPlane: %d %d\nVertical: %d\n\n",
				parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],
				parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		#endif

	}
	
	puts("\n\nFinished parsing from the SD Card, returning to terminal mode . . . \n");
	
	f_close(&file_object);	
	
	return 0;
}


static FRESULT scan_files(char *path)
{
	FRESULT res;
	FILINFO fno;
	DIR dir;
	int32_t i;
	char *pc_fn;
	#if _USE_LFN
	char c_lfn[_MAX_LFN + 1];
	fno.lfname = c_lfn;
	fno.lfsize = sizeof(c_lfn);
	#endif

	/* Open the directory */
	res = f_opendir(&dir, path);
	if (res == FR_OK) {
		i = strlen(path);
		for (;;) {
			res = f_readdir(&dir, &fno);
			if (res != FR_OK || fno.fname[0] == 0) {
				break;
			}

			#if _USE_LFN
			pc_fn = *fno.lfname ? fno.lfname : fno.fname;
			#else
			pc_fn = fno.fname;
			#endif
			if (*pc_fn == '.') {
				continue;
			}

			/* Check if it is a directory type */
			if (fno.fattrib & AM_DIR) {
				sprintf(&path[i], "/%s", pc_fn);
				res = scan_files(path);
				if (res != FR_OK) {
					break;
				}

				path[i] = 0;
				} else {
				printf("%s/%s\n\r", path, pc_fn);
			}
		}
	}

	return res;
}


uint8_t display_file_tree()
{
	FRESULT res;
	DIR dirs;
	TCHAR root_directory[3] = "0:";

	static FATFS fs;

	root_directory[0] = '0' + 0;

	/* Mount disk*/
	printf("-I1- Mount disk 0\n\r");
	/* Clear file system object */
	memset(&fs, 0, sizeof(FATFS));
	res = f_mount( &fs, "", 0);
	if (res != FR_OK)
	{
		printf("-E1- f_mount error code: 0x%d\n\r", res);
		return 0;
	}

	/* Test if the disk is formatted */
	res = f_opendir(&dirs, root_directory);
	if (res == FR_OK)
	{
		puts("-I2- The disk is properly formatted.\r");

		/* Display the file tree */
		puts("-I3- Displaying files contained in the memory :\r");
		strcpy((char *)data_buffer, root_directory);
		scan_files((char *)data_buffer);
	}else
	{
		printf("-E3- f_opendir error code: 0x%d\n\r", res);
		return 0;
	}
	
	/* Unmount disk */
	puts("-I11- Unmount disk\r");
	res = f_mount(NULL, "", 0);
	if (res != FR_OK)
	{
		printf("-E1- f_mount error code: 0x%d\n\r", res);
		return 0;
	}
	
	return 1;
}


uint8_t fatfs_example()
{
	FRESULT res;
	DIR dirs;
	TCHAR root_directory[3] = "0:";

	TCHAR write_file_name[12] = "write.txt";
	TCHAR read_file_name[12] = "read.txt";

	static FATFS fs;
	static FIL file_object;

	root_directory[0] = '0' + 0;

	/* Mount disk*/
	printf("-I1- Mount disk 0\n\r");
	/* Clear file system object */
	memset(&fs, 0, sizeof(FATFS));
	res = f_mount( &fs, "", 0);
	if (res != FR_OK)
	{
		printf("-E1- f_mount error code: 0x%d\n\r", res);
		return 0;
	}
	

	/* Test if the disk is formatted */
	res = f_opendir(&dirs, root_directory);
	if (res == FR_OK)
	{
		/* Erase sd card to reformat it ? */
		puts("-I2- The disk is already formatted.\r");

		/* Display the file tree */
		puts("-I3- Display files contained in the memory :\r");
		strcpy((char *)data_buffer, root_directory);
		scan_files((char *)data_buffer);
	} else if (res == FR_NO_FILESYSTEM)
	{

		/* Format disk */
		printf("-I5- Format disk 0\n\r");
		puts("-I6- Please wait a moment during formatting...\r");
		res = f_mkfs("", 0, 512);
		puts("-I7- Disk format finished !\r");
		if (res != FR_OK)
		{
			printf("-E2- f_mkfs error code: 0x%d\n\r", res);
			return 0;
		}

	} else if (FR_OK != res)
	{
		printf("-E3- f_opendir error code: 0x%d\n\r", res);
		return 0;
	}

	

	/* Create/write to a new file */
	printf("-I9- Create a file : \"%s\"\n\r", write_file_name);
	res = f_open(&file_object, (char const *)write_file_name, FA_CREATE_ALWAYS|FA_WRITE);
	if (res != FR_OK)
	{
		printf("-E4- f_open create error code: 0x%d\n\r", res);
		return 0;
	}
	
	
	f_printf(&file_object, "-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
	f_puts("Done writing\0",&file_object);
	
	
	
	
	/* Read from a file */
	printf("-I9- Read a file : \"%s\"\n\r", read_file_name);
	res = f_open(&file_object,(char const *)read_file_name, FA_READ);
	if (res != FR_OK)
	{
		printf("-E4- f_open read error code: 0x%d\n\r", res);
		return 0;
	}
	
	char temp[128];
	while(!f_eof(&file_object))
	{
		puts("-------");
		f_gets(temp,128,&file_object);
		puts(temp);
		puts("-------");
	}




	/* Close the file */
	puts("-I11- Close file\r");
	res = f_close(&file_object);
	if (res != FR_OK)
	{
		printf("-E6- f_close error code: 0x%d\n\r", res);
		return 0;
	}
	
	/* Unmount disk */
	puts("-I11- Unmount disk\r");
	res = f_mount(NULL, "", 0);
	if (res != FR_OK)
	{
		printf("-E1- f_mount error code: 0x%d\n\r", res);
		return 0;
	}
	
	return 1;
}



