/* Auto-generated config file hpl_hsmci_config.h */
#ifndef HPL_HSMCI_CONFIG_H
#define HPL_HSMCI_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

#include "peripheral_clk_config.h"

#ifndef CONF_HCLK_FREQUENCY
#define CONF_HCLK_FREQUENCY 300000000
#endif

#ifndef CONF_HSMCI_SYS_CLK
#define CONF_HSMCI_SYS_CLK CONF_HCLK_FREQUENCY
#endif

// <<< end of configuration section >>>

#endif // HPL_HSMCI_CONFIG_H
