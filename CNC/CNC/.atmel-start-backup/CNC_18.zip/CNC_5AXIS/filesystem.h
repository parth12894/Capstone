#ifndef FILESYSTEM_H_
#define FILESYSTEM_H_


#define DATA_SIZE 2048

uint8_t fatfs_example();

uint8_t execute_from_sd_card();

#endif