#ifndef CNC_5Axis_h
#define	CNC_5Axis_h


// Globals defines
#define N_AXIS 5
#define STEPS_PER_MM 640.0
#define STEPS_PER_RADIAN 127.0
#define MOTION_BUFFER_SIZE 2048
#define PI 3.14158265358979323846

#ifndef sign
    #define sign(x) ((x>=0)-(x<0))
#endif

#define HIGH true
#define LOW false

#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2
#define A_AXIS 3
#define C_AXIS 4


//Debugging
#define DEBUG 1
//#define DEBUG_FILE 1

// C Libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <string.h>

//Project Libraries
#include "inv_kin.h"
#include "motion_buffer.h"
#include "motion_control.h"
#include "parser.h"
#include "useful_functions.h"
#include "pin_define.h"
#include "stepper.h"
#include "filesystem.h"

//Atmel Libraries
#include <atmel_start.h>
#include <diskio.h>
#include <ff.h>
#include <sd_mmc.h>
#include <sd_mmc_protocol.h>


#endif


