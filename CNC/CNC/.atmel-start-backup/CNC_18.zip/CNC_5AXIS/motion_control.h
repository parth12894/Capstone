#ifndef motion_control_h
#define motion_control_h

#define total_secant_error 0.005
#define error_correction_count 5
#define min_segments 10

void add_linear_motion(float *target, float* offset);
void add_arc_motion(float *position, float *target, float *offset, uint8_t axis_0, uint8_t axis_1, uint8_t axis_linear, uint8_t is_CW);

#endif