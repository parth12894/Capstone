#include "CNC_5Axis.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//typedef struct
//{
	//uint16_t n_step;          // Number of step events to be executed for this segment
	//uint8_t st_block_index;   // Stepper block data index. Uses this information to execute this segment.
//} segment_t;
//
//// Stepper ISR data struct. Contains the running data for the main stepper ISR.
//typedef struct
//{
	//// Used by the bresenham line algorithm
	//uint32_t counter_x,        // Counter variables for the bresenham line tracer
	//counter_y,
	//counter_z,
	//counter_a,
	//counter_c;
//
	////uint8_t execute_step;     // Flags step execution for each interrupt.
	////uint8_t step_pulse_time;  // Step pulse reset time after step rise
	////uint16_t step_count;       // Steps remaining in line segment motion
	//uint8_t exec_block_index; // Tracks the current st_block index. Change indicates new block.
	//motion_block_t *exec_block;   // Pointer to the block data for the segment being executed
	//segment_t *exec_segment;  // Pointer to the segment being executed
//} stepper_t;
//static stepper_t st;
//static segment_t segment_buffer[MOTION_BUFFER_SIZE];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
volatile uint8_t x_enable;
volatile uint8_t y_enable;
volatile uint8_t z_enable;
volatile uint8_t a_enable;
volatile uint8_t c_enable;

uint32_t counter_x,        // Counter variables for the Bresenham line tracer
counter_y,
counter_z,
counter_a,
counter_c;


volatile uint32_t step_events_completed = 0;

static motion_block_t *current_block;

static struct timer_task task0, task1;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void task0_cb(const struct timer_task *const timer_task)
{

	if (current_block == NULL)
	{
		delay_ms(1000);
		current_block = get_motion_block();
		if (current_block == NULL)
		{
			ISR_disable();
			return;
		}
		
		// Initialize Bresenham line and distance counters
		step_events_completed = 0;
		counter_x = counter_y = counter_z = counter_a = counter_c = (current_block->step_event_count >> 1);
		
		
		//if(st.exec_block->dir_x == 1)
			//gpio_set_pin_level(X_DIR, true);
		//else
			//gpio_set_pin_level(X_DIR, false);
//
		//if(st.exec_block->dir_y == 1)
			//gpio_set_pin_level(Y_DIR, true);
		//else
			//gpio_set_pin_level(Y_DIR, false);
//
		//if(st.exec_block->dir_z == 1)
			//gpio_set_pin_level(Z_DIR, true);
		//else
			//gpio_set_pin_level(Z_DIR, false);
//
		//if(st.exec_block->dir_a == 1)
			//gpio_set_pin_level(A_DIR, true);
		//else
			//gpio_set_pin_level(A_DIR, false);
//
		//if(st.exec_block->dir_c == 1)
			//gpio_set_pin_level(C_DIR, true);
		//else
			//gpio_set_pin_level(C_DIR, false);
		
		
		
		
		
		

		
	}
	
	counter_x += current_block->steps[X_AXIS];
	if (counter_x > current_block->step_event_count)
	{
		x_enable = 1;
		counter_x -= current_block->step_event_count;
	}
	counter_y += current_block->steps[Y_AXIS];
	if (counter_y > current_block->step_event_count)
	{
		y_enable = 1;
		counter_y -= current_block->step_event_count;
	}
	counter_z += current_block->steps[Z_AXIS];
	if (counter_z > current_block->step_event_count)
	{
		z_enable = 1;
		counter_z -= current_block->step_event_count;
	} 
	
	/************************************************** a and c axis ****/  
	counter_a += current_block->steps[A_AXIS];
	if (counter_a > current_block->step_event_count)
	{
		a_enable = 1;
		counter_a -= current_block->step_event_count;
	}
	counter_c += current_block->steps[C_AXIS];
	if (counter_c > current_block->step_event_count)
	{
		c_enable = 1;
		counter_c -= current_block->step_event_count;
	} 

	/************************************************** a and c axis ****/
	
	step_events_completed++;	

	if (x_enable == 1)
		gpio_set_pin_level(X_STEP, true);
	if (y_enable == 1)
		gpio_set_pin_level(Y_STEP, true);
	if (z_enable == 1)
		gpio_set_pin_level(Z_STEP, true);
	if (a_enable == 1)
		gpio_set_pin_level(A_STEP, true);
	if (c_enable == 1)
		gpio_set_pin_level(C_STEP, true);

	timer_add_task(&TIMER_0, &task1);

	if (step_events_completed >= current_block->step_event_count)
	{
		current_block = NULL;
		increment_current_block();	
	}


}

void task1_cb(const struct timer_task *const timer_task)
{
	gpio_set_pin_level(X_STEP, false);
	gpio_set_pin_level(Y_STEP, false);
	gpio_set_pin_level(Z_STEP, false); 
	gpio_set_pin_level(A_STEP, false);
	gpio_set_pin_level(C_STEP, false);
	x_enable = 0;
	y_enable = 0;
	z_enable = 0; 
	a_enable = 0; 
	c_enable = 0;
}

void ISR_init()
{
	// Starting the ISR

	task0.interval = 200;//make sure that these values are NOT the same, if they are they MAY NOT RUN
	task0.cb = task0_cb;
	task0.mode = TIMER_TASK_REPEAT;

	task1.interval = 100; //make sure that these values are NOT the same, if they are they MAY NOT RUN
	task1.cb = task1_cb;
	task1.mode = TIMER_TASK_ONE_SHOT;
	
	printf("+++++\n");
	
	timer_add_task(&TIMER_0, &task0);
	
	
	printf("*****\n");
	return;

}

void ISR_enable()
{
	timer_add_task(&TIMER_0, &task0);
	return;
}

void ISR_disable()
{
	
	timer_remove_task(&TIMER_0, &task0);
	return;
}
