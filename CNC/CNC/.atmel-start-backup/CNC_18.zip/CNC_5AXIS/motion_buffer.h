#ifndef motion_buffer_h
#define motion_buffer_h

typedef struct{
	
	// Used for stepper control
	uint32_t steps[N_AXIS];
	uint32_t max_step_count;
	
	/* Custom */
	uint32_t step_event_count; //largest step number in block
	uint8_t dir_x:1, dir_y:1, dir_z:1, dir_a:1, dir_c:1;
	/* Custom*/
	
	// Used for acceleration
	float start_speed;
	float max_start_speed;
	float flat_speed;
	float acceleration;
	float millimeters;
	float radians;
}motion_block_t;

static motion_block_t motion_buffer[MOTION_BUFFER_SIZE];


/*Adds a linear motion block to the head of the motion buffer*/
void update_motion_buffer(float* target, float*offset);
motion_block_t *get_motion_block();

void increment_current_block();	

#endif