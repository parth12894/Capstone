#ifndef STEPPER_H_
#define STEPPER_H_


extern struct timer_task task0;
#define ISR_EN() timer_start(&TIMER_1);

void ISR_init();

static inline void ISR_enable();

static inline void ISR_disable();

void serial_init();
#endif