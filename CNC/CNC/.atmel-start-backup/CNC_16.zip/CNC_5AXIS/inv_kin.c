#include "CNC_5Axis.h"

void* inv_kin_slow(float *out, float *pose, float *offset){
    //A
    out[3] = acos(cos(pose[3])); 
    //C
    out[4] = atan2(sin(pose[4])*sin(pose[3]),cos(pose[4]*sin(pose[3])));
    // X
    out[0] = cos(pose[4])*(pose[0]-offset[0]) - sin(pose[4])*(pose[1]-offset[1]);
    // Y
    out[1] = sin(pose[4])*cos(pose[3])*(pose[0]-offset[0]) +
        cos(pose[4])*cos(pose[3])*(pose[1]-offset[1]) - 
        sin(pose[3])*(pose[2]-offset[2]);
    // Z
    out[2] = sin(pose[4])*sin(pose[3])*(pose[0]-offset[0]) +
        cos(pose[4])*sin(pose[3])*(pose[1]-offset[1]) + 
        cos(pose[3])*(pose[2]-offset[2]);
    
	return 0;
}