#include "CNC_5AXIS/CNC_5Axis.h"



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main()
{
	atmel_start_init(); 
	delay_ms(1000);
parser_init();

char line[128]= "G1 X10 Y20";

	parse_line(line);
	// run isr.

	while (1)
	{
	}

	return 0;
}


