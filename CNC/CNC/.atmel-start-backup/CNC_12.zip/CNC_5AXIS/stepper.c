#include "CNC_5Axis.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
	uint16_t n_step;          // Number of step events to be executed for this segment
	uint8_t st_block_index;   // Stepper block data index. Uses this information to execute this segment.
} segment_t;

// Stepper ISR data struct. Contains the running data for the main stepper ISR.
typedef struct
{
	// Used by the bresenham line algorithm
	uint32_t counter_x,        // Counter variables for the bresenham line tracer
	counter_y,
	counter_z,
	counter_a,
	counter_c;

	uint8_t execute_step;     // Flags step execution for each interrupt.
	uint8_t step_pulse_time;  // Step pulse reset time after step rise
	uint8_t step_outbits;         // The next stepping-bits to be output
	uint8_t dir_outbits;
	uint16_t step_count;       // Steps remaining in line segment motion
	uint8_t exec_block_index; // Tracks the current st_block index. Change indicates new block.
	motion_block_t *exec_block;   // Pointer to the block data for the segment being executed
	segment_t *exec_segment;  // Pointer to the segment being executed
} stepper_t;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
volatile uint8_t x_enable = 1;
volatile uint8_t y_enable = 1;
volatile uint8_t z_enable = 1;
volatile uint8_t a_enable = 1;
volatile uint8_t c_enable = 1;

volatile uint32_t step_events_completed = 0;

volatile uint32_t motion_buffer_head;

static stepper_t st;
static segment_t segment_buffer[motion_buffer_size];
static motion_block_t motion_buffer[motion_buffer_size];

static struct timer_task task_stepper_ISR, task_set_pins_low;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void stepper_ISR(const struct timer_task *const timer_task)
{

	if (st.exec_segment == NULL)
	{
		delay_ms(1000);

		st.exec_segment = &segment_buffer[motion_buffer_head];
		st.step_count = ((st.exec_segment->n_step)); // NOTE: Can sometimes be zero when moving slow.
		st.exec_block_index = st.exec_segment->st_block_index;
		st.exec_block = &motion_buffer[st.exec_block_index];
		
		
		step_events_completed = 0;
		
		
		if(st.exec_block->dir_x ==1)
			gpio_set_pin_level(xdir, true);
		else
			gpio_set_pin_level(xdir, false);

		if(st.exec_block->dir_y ==1)
			gpio_set_pin_level(ydir, true);
		else
			gpio_set_pin_level(ydir, false);

		if(st.exec_block->dir_z ==1)
			gpio_set_pin_level(zdir, true);
		else
			gpio_set_pin_level(zdir, false);

		if(st.exec_block->dir_a ==1)
			gpio_set_pin_level(adir, true);
		else
			gpio_set_pin_level(adir, false);

		if(st.exec_block->dir_c ==1)
			gpio_set_pin_level(cdir, true);
		else
			gpio_set_pin_level(cdir, false);
		
		
		
		
		// Initialize Bresenham line and distance counters
		st.counter_x = st.counter_y = st.counter_z = st.counter_a = st.counter_c = (st.exec_block->step_event_count >> 1);

		
	}
	
	st.counter_x += st.exec_block->steps[X_AXIS];
	if (st.counter_x > st.exec_block->step_event_count)   //if (st.counter_x > st.exec_block->step_event_count)
	{
		x_enable = 1;
		st.counter_x -= st.exec_block->step_event_count;
	}
	st.counter_y += st.exec_block->steps[Y_AXIS];
	if (st.counter_y > st.exec_block->step_event_count)
	{
		y_enable = 1;
		st.counter_y -= st.exec_block->step_event_count;
	}
	st.counter_z += st.exec_block->steps[Z_AXIS];
	if (st.counter_z > st.exec_block->step_event_count)
	{
		z_enable = 1;
		st.counter_z -= st.exec_block->step_event_count;
	} 
	

	/************************************************** a and c axis ****/  
	
	/* Responsible for "delaying" the steps of the ac axis until the ratio has been met, this ensures that the ac 
	axis runs at a different rate compared to the xyz axis*/

		st.counter_a += st.exec_block->steps[A_AXIS];
		if (st.counter_a > st.exec_block->step_event_count)
		{ 
			a_enable = 1;
			st.counter_a -= st.exec_block->step_event_count;
		}
		st.counter_c += st.exec_block->steps[C_AXIS];
		if (st.counter_c > st.exec_block->step_event_count)
		{ 
			c_enable = 1;
			st.counter_c -= st.exec_block->step_event_count;
		}  

	/************************************************** a and c axis ****/
	
	step_events_completed++;	

	if (x_enable == 1){
		gpio_set_pin_level(xstep, true);
	}
	if (y_enable == 1){
		gpio_set_pin_level(ystep, true);
	}

	if (z_enable == 1){
		gpio_set_pin_level(zstep, true);
	} 
	if (a_enable == 1){
		gpio_set_pin_level(astep, true);
	} 
	if (c_enable == 1){
		gpio_set_pin_level(cstep, true);
	}

	timer_add_task(&TIMER_0, &task_set_pins_low);

	if (step_events_completed >= st.exec_block->step_event_count)
	{
		if ( ++motion_buffer_head == motion_buffer_size)  //starting a new block
		{
			timer_remove_task(&TIMER_0, &task_stepper_ISR);
			motion_buffer_head = 0;
			return;
		}
		st.exec_segment = NULL;
	}


}

void set_pins_low(const struct timer_task *const timer_task)
{
	gpio_set_pin_level(xstep, false);
	gpio_set_pin_level(ystep, false);
	gpio_set_pin_level(zstep, false); 
	gpio_set_pin_level(astep, false);
	gpio_set_pin_level(cstep, false);
	x_enable = 0;
	y_enable = 0;
	z_enable = 0; 
	a_enable = 0; 
	c_enable = 0;
}

void ISR_init()
{
	// Starting the ISR

	task_stepper_ISR.interval = 200;//make sure that these values are NOT the same, if they are they MAY NOT RUN
	task_stepper_ISR.cb = stepper_ISR;
	task_stepper_ISR.mode = TIMER_TASK_REPEAT;

	task_set_pins_low.interval = 100; //make sure that these values are NOT the same, if they are they MAY NOT RUN
	task_set_pins_low.cb = set_pins_low;
	task_set_pins_low.mode = TIMER_TASK_ONE_SHOT;

	timer_add_task(&TIMER_0, &task_stepper_ISR);
	timer_start(&TIMER_0);

}




