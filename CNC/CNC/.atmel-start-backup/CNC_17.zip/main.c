#include "CNC_5AXIS/CNC_5Axis.h"



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** Size of the file to write/read. */
#define DATA_SIZE 2048

/** Test settings: Number of bytes to test */
#define TEST_SIZE   (4 * 1024)

/** Example header */
#define STRING_EOL    "\r"




/* Read/write buffer */
static uint8_t data_buffer[DATA_SIZE];


static FRESULT scan_files(char *path)
{
	FRESULT res;
	FILINFO fno;
	DIR dir;
	int32_t i;
	char *pc_fn;
#if _USE_LFN
	char c_lfn[_MAX_LFN + 1];
	fno.lfname = c_lfn;
	fno.lfsize = sizeof(c_lfn);
#endif

	/* Open the directory */
	res = f_opendir(&dir, path);
	if (res == FR_OK) {
		i = strlen(path);
		for (;;) {
			res = f_readdir(&dir, &fno);
			if (res != FR_OK || fno.fname[0] == 0) {
				break;
			}

#if _USE_LFN
			pc_fn = *fno.lfname ? fno.lfname : fno.fname;
#else
			pc_fn = fno.fname;
#endif
			if (*pc_fn == '.') {
				continue;
			}

			/* Check if it is a directory type */
			if (fno.fattrib & AM_DIR) {
				sprintf(&path[i], "/%s", pc_fn);
				res = scan_files(path);
				if (res != FR_OK) {
					break;
				}

				path[i] = 0;
			} else {
				printf("%s/%s\n\r", path, pc_fn);
			}
		}
	}

	return res;
}




static uint8_t run_fatfs_test(uint32_t disk_dev_num)
{
	uint32_t i;
	UINT byte_to_read;
	UINT byte_read;
	#if _FS_READONLY == 0
		UINT byte_written;
	#endif

	FRESULT res;
	DIR dirs;
	TCHAR root_directory[3] = "0:";
	/* File name to be validated */
	TCHAR file_name[12] = "0:Basic.bin";


	static FATFS fs;
	static FIL file_object;

	root_directory[0] = '0' + disk_dev_num;
	file_name[0] = '0' + disk_dev_num;

	/* Mount disk*/
	printf("-I1- Mount disk %d\n\r", (int)disk_dev_num);
	/* Clear file system object */
	memset(&fs, 0, sizeof(FATFS));
	res = f_mount( &fs, disk_dev_num, 1);
	if (res != FR_OK) 
	{
		printf("-E1- f_mount pb: 0x%X\n\r", res);
		return 0;
	}

	/* Test if the disk is formatted */
	res = f_opendir(&dirs, root_directory);
	if (res == FR_OK) 
	{
		/* Erase sd card to reformat it ? */
		puts("-I2- The disk is already formatted.\r");

		/* Display the file tree */
		puts("-I3- Display files contained in the memory :\r");
		strcpy((char *)data_buffer, root_directory);
		scan_files((char *)data_buffer);


		puts("-I4- The disk will be re-formatted.\r");
		res = FR_NO_FILESYSTEM;
	}

	
	
	
	if (res == FR_NO_FILESYSTEM) 
	{

		/* Format disk */
		printf("-I5- Format disk %d\n\r", (int)disk_dev_num);
		puts("-I6- Please wait a moment during formatting...\r");
		res = f_mkfs(disk_dev_num, 0, 512);
		printf("-- temp1: 0x%X\n\r", res);
		puts("-I7- Disk format finished !\r");
		if (res != FR_OK) 
		{
			printf("-E2- f_mkfs pb: 0x%X\n\r", res);
			return 0;
		}

	} else if (FR_OK != res) 
	{
		printf("-E3- f_opendir pb: 0x%X\n\r", res);
		return 0;
	}
	
	
	
		/* Test if the disk is formatted */
		res = f_opendir(&dirs, root_directory);
		if (FR_OK != res)
		{
			printf("-E3 - temp- f_opendir pb: 0x%X\n\r", res);
			//return 0;
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/* Create a new file */
	printf("-I9- Create a file : \"%s\"\n\r", file_name);
	res = f_open(&file_object, (char const *)file_name,  FA_WRITE);
	if (res != FR_OK) 
	{
		printf("-E4- f_open create pb: 0x%d\n\r", res);
		return 0;
	}

	/* Write a checkerboard pattern in the buffer */
	for (i = 0; i < sizeof(data_buffer); i++) 
	{
		if ((i & 1) == 0) 
		{
			data_buffer[i] = (i & 0x55);
		} else 
		{
			data_buffer[i] = (i & 0xAA);
		}
	}
	puts("-I10- Write file\r");
	for (i = 0; i < TEST_SIZE; i += DATA_SIZE) 
	{
		res = f_write(&file_object, data_buffer, DATA_SIZE,	&byte_written);

		if (res != FR_OK) 
		{
			printf("-E5- f_write pb: 0x%X\n\r", res);
			return 0;
		}
	}

	/* Close the file */
	puts("-I11- Close file\r");
	res = f_close(&file_object);
	if (res != FR_OK)
	{
		printf("-E6- f_close pb: 0x%X\n\r", res);
		return 0;
	}





































	/* Open the file */
	printf("-I12- Open the same file : \"%s\"\n\r", file_name);
	res = f_open(&file_object, (char const *)file_name,	FA_OPEN_EXISTING | FA_READ);
	if (res != FR_OK) 
	{
		printf("-E7- f_open read pb: 0x%X\n\r", res);
		return 0;
	}

	/* Read file */
	puts("-I13- Read file\r");
	memset(data_buffer, 0, DATA_SIZE);
	byte_to_read = file_object.fsize;

	for (i = 0; i < byte_to_read; i += DATA_SIZE) 
	{
		res = f_read(&file_object, data_buffer, DATA_SIZE, &byte_read);
		if (res != FR_OK) 
		{
			printf("-E8- f_read pb: 0x%X\n\r", res);
			return 0;
		}
	}

	/* Close the file*/
	puts("-I14- Close file\r");
	res = f_close(&file_object);
	if (res != FR_OK) 
	{
		printf("-E9- f_close pb: 0x%X\n\r", res);
		return 0;
	}

	/* Compare the read data with the expected data */
	for (i = 0; i < sizeof(data_buffer); i++) 
	{
		if (!((((i & 1) == 0) && (data_buffer[i] == (i & 0x55))) || (data_buffer[i] == (i & 0xAA)))) 
			printf(
					"Invalid data at data[%u] (expected 0x%02X, read 0x%02X)\n\r",
					(unsigned int)i,
					(unsigned int)(((i & 1) == 0) ? (i & 0x55) : (i & 0xAA)),
					(unsigned int)data_buffer[i]);
	}
	puts("-I15- File data Ok !\r");

	return 1;
}




int main()
{
	atmel_start_init(); 
	
	
	
	//sd Card test
	
	char test_file_name[] = "0:test.txt";
	FRESULT res;
	FATFS fs;
	FIL file_object;
	
	
	printf("\x0C\n\r-- SD/MMC/SDIO Card Example on FatFs --\n\r");
	printf("-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
	

	uint32_t disk_dev_num;
	
	
	sd_mmc_err_t err;
	
	
	
	
	do {
		err = sd_mmc_check(0);
	} while (SD_MMC_OK != err);
	
	
	
	
	while (1)
	{
		
		printf("Please plug an SD, MMC or SDIO card in slot.\n\r");

		/* Wait card present and ready */
		do 
		{
			err = sd_mmc_check(0);
			if (SD_MMC_OK == err)
			{
				printf("Card install FAIL\n\r");
				printf("Please unplug and re-plug the card.\n\r");
				while (CTRL_NO_PRESENT != sd_mmc_check(0))
				{
				}
			}
		} while (SD_MMC_OK != err);


		for (disk_dev_num = 0; disk_dev_num < 1; disk_dev_num++) {
			if (run_fatfs_test(disk_dev_num)) {
				printf("-I- DISK %d Test passed !\n\r\n\r", (int)disk_dev_num);
				} else {
				printf("-F- DISK %d Test Failed !\n\r\n\r", (int)disk_dev_num);
			}
		}
		while(1){}
	
	}
	
	
	
	
	/*
	
	//Jasons Parser test
	
	delay_ms(1000);

	printf(">>");
	
	char line[128];
	parser_init();
	while(1)
	{
		
	
		fgets(line, sizeof(line), stdin);
		parse_line(line);
	
		
		printf("ok\n");
	}
*/

	while (1){};
}










//
//"G0 X0.000 Y0.000 Z10.000"
//"G0 X0.000 Y0.000 Z1.000\n"
//"G1 X0.000 Y0.000 Z-0.150\n"
//"G1 X30.000 Y0.000\n"
//"G1 X30.000 Y30.000\n"
//"G1 X0.000 Y30.000\n"
//"G1 X0.000 Y0.000\n"
//"G1 X0.000 Y0.000 Z5.000\n"
//"G1 X28.75 Y15.00\n"
//"G1 X28.75 Y15.00 Z1.000\n"
//"G1 X28.75 Y15.00 Z-0.150\n"
//"G3 X28.75 Y15.00 I-13.75 J0.000\n"
//"G0 X28.75 Y15.00 Z5.000\n"
//"G0 X20.00 Y15.00\n"
//"G0 X20.00 Y15.00 Z1.000\n"
//"G1 X20.00 Y15.00 Z-0.15\n"
//"G3 X20.00 Y15.00 I-5.000 J0.000\n"
//"G0 X20.00 Y15.00 Z10.000\n"
//"G0 X0.000 Y0.000\n"