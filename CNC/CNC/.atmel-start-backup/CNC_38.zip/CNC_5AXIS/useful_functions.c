#include "CNC_5Axis.h"

float get_float_after_letter(char * str,uint8_t *char_counter)
{
    char float_str[9] = {0};
    uint8_t float_ctr = 0;
    
    while(str[*char_counter]!=' '&&str[*char_counter]!=0){
        float_str[float_ctr] = str[*char_counter];
        float_ctr++;
        *char_counter = *char_counter + 1;
    }
    
    return atof(float_str);
}



void sanity_check()
{
	printf("====================Sanity Check=====================\n");
	delay_ms(1000);
	puts("\n>> Command: G0 X0 Y0 F900");	parse_line("G0 X0 Y0 F900");
	puts("\n>> Command: G1 X75 Y0");		parse_line("G1 X75 Y0");
	puts("\n>> Command: M3 S75");			parse_line("M3 S75");
	puts("\n>> Command: G4 P3");			parse_line("G4 P3");
	puts("\n>> Command: G1 X75 Y75");		parse_line("G1 X75 Y75");
	puts("\n>> Command: G4 P3");			parse_line("G4 P3");
	puts("\n>> Command: G1 X0 Y75");		parse_line("G1 X0 Y75");
	puts("\n>> Command: M5");				parse_line("M5");
	puts("\n>> Command: G4 P3");			parse_line("G4 P3");
	puts("\n>> Command: G1 X0 Y0");			parse_line("G1 X0 Y0");
	printf("================Sanity Check Complete================\n");
	
	return;
}


