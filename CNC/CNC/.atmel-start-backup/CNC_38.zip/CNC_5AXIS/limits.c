#include "CNC_5Axis.h"

extern struct timer_task stepper_ISR_task;

uint8_t limis[N_AXIS];

int i = 0;
bool is_error_state = false;

static void x_lim_pressed()
{
	if(i==0)
	{
		i++;
		return;
	}
	
	is_error_state = true;
	printf("\n %d", i);i++;
	delay_us(100);
	ISR_DIS();
	return;
}

void limits_init()
{
	
	printf(">>SCDR read %#0x \n", hri_pio_read_SCDR_reg(PIOD));
	
	hri_pio_write_SCDR_reg(PIOD, 0x0000000F);
	hri_pio_set_IFSR_P26_bit(PIOD);
	hri_pio_set_IFSCSR_P26_bit(PIOD);
	ext_irq_register(PIO_PD26_IDX, x_lim_pressed);
	printf(">>SCDR read %#0x \n", hri_pio_read_SCDR_reg(PIOD));
	return;
}