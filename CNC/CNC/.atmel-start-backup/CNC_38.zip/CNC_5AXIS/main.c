#include "CNC_5AXIS/CNC_5Axis.h"



int main()
{
	atmel_start_init();
	
	
	
	
	//
	//int hw, mask;
	//
	//mask = 1U << GPIO_PIN(X_DIR);
	//printf(">>X_dir mask  %#0x \n", mask);
	//hw = (uint32_t)PIOA + 0x3 * 0x200;
	//printf(">>X_dir hw %#0x \n", hw);
	//printf(">>PIOD %#0x \n", (uint32_t)PIOD);
	//
	
	
	
	
	
	spindle_init();
	parser_init();
	limits_init();
	stepper_init();
	

	printf("\n\t\t--  PP01 - 5 Axis CNC Controller  --\n");
	printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
	
	char input[128];
	while(1)
	{
		printf("\n>>");
		fgets(input, sizeof(input), stdin);
		puts(input);
		parse_line(input);
	
		#if DEBUG
			printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],parser_input.ijk[0],parser_input.ijk[1],parser_input.ijk[2],parser_input.feedrate);
			printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %.2f\nPlane: %d %d\nVertical: %d\n\n",parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		#endif
	}
	
	
	for(;;);
	
	return 0;
}








