#ifndef LIMITS_H_
#define LIMITS_H_



extern uint8_t limis[N_AXIS];

void limits_init();

#endif