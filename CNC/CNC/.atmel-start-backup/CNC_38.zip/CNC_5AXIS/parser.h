#ifndef PARSER_H_
#define PARSER_H_


#define GCODE 0
#define MCODE 1

#define ABS_MODE 0
#define INC_MODE 1


// used to keep track of G-code inputs
typedef struct{

    float feedrate; //feedrate in units/min
    float ijk[3]; // for offsets
    float xyzac[5]; // for target position
	
	uint32_t p,s;
	
	uint8_t code;
}parser_input_t;

extern parser_input_t parser_input;

// used to keep track of state of machine
typedef struct{

    float feedrate; // current feedrate of the tool
    float position[5]; //current position of the tool 
    uint8_t plane[2]; // plane of curve motions. Default:XY
    uint8_t axis_linear; // linear axis for Helical motion
	
	float multiplier;
	uint8_t abs_or_inc;
	uint32_t spindle_speed;
}parser_state_t;

extern parser_state_t parser_state;

void parser_init();

void parse_line(char *line);

#endif