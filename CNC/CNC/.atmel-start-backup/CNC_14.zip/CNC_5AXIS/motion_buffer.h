#ifndef motion_buffer_h
#define motion_buffer_h

typedef struct{
    
    // Used for stepper control
    uint32_t steps[N_Axis];
    uint32_t step_count;
	
	/* Custom */
	uint32_t step_event_count; //largest step number in block
	uint8_t dir_x, dir_y, dir_z, dir_a, dir_c;
	/* Custom*/
    
    // Used for acceleration
    float start_speed;
    float max_start_speed;
    float flat_speed;
    float acceleration;
    float millimeters;
    float radians;
}motion_block_t;

/*Adds a linear motion block to the tail of the motion buffer*/
void update_motion_buffer(float* target, float*offset);
motion_block_t *get_motion_block();

#endif