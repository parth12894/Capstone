/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef ATMEL_START_PINS_H_INCLUDED
#define ATMEL_START_PINS_H_INCLUDED

#include <hal_gpio.h>

// SAME70 has 4 pin functions

#define GPIO_PIN_FUNCTION_A 0
#define GPIO_PIN_FUNCTION_B 1
#define GPIO_PIN_FUNCTION_C 2
#define GPIO_PIN_FUNCTION_D 3

#define D7 GPIO(GPIO_PORTA, 2)
#define D2 GPIO(GPIO_PORTA, 5)
#define D3 GPIO(GPIO_PORTA, 6)
#define D36 GPIO(GPIO_PORTA, 13)
#define D8 GPIO(GPIO_PORTA, 17)
#define A3 GPIO(GPIO_PORTA, 19)
#define D46 GPIO(GPIO_PORTA, 21)
#define D43 GPIO(GPIO_PORTA, 23)
#define D45 GPIO(GPIO_PORTA, 24)
#define D44 GPIO(GPIO_PORTA, 25)
#define D33 GPIO(GPIO_PORTA, 26)
#define PA27 GPIO(GPIO_PORTA, 27)
#define D49 GPIO(GPIO_PORTA, 28)
#define D48 GPIO(GPIO_PORTA, 30)
#define D41 GPIO(GPIO_PORTA, 31)
#define D47 GPIO(GPIO_PORTB, 4)
#define A12 GPIO(GPIO_PORTB, 13)
#define D9 GPIO(GPIO_PORTC, 9)
#define A4 GPIO(GPIO_PORTC, 13)
#define CARD_DETECT_0 GPIO(GPIO_PORTC, 16)
#define D6 GPIO(GPIO_PORTC, 19)
#define A1 GPIO(GPIO_PORTC, 31)
#define A13 GPIO(GPIO_PORTD, 0)
#define D5 GPIO(GPIO_PORTD, 11)
#define D12 GPIO(GPIO_PORTD, 20)
#define D11 GPIO(GPIO_PORTD, 21)
#define D13 GPIO(GPIO_PORTD, 22)
#define D10 GPIO(GPIO_PORTD, 25)
#define A0 GPIO(GPIO_PORTD, 26)
#define D20 GPIO(GPIO_PORTD, 27)
#define A2 GPIO(GPIO_PORTD, 30)

#endif // ATMEL_START_PINS_H_INCLUDED
