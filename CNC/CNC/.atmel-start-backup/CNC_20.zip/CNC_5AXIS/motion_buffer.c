#include "CNC_5Axis.h"



// unused 
	/*
	typedef struct{
		uint32_t position[N_AXIS]; // in steps
		float direction[N_AXIS];
		float prev_speed;
	} pos_info_t;
	static pos_info_t pos;
	*/


//static motion_block_t motion_buffer[MOTION_BUFFER_SIZE];
static volatile int motion_buffer_head;
static volatile int motion_buffer_tail;

void update_motion_buffer(float* target_pose, float* offset){

    int i;
    uint32_t target_steps[N_AXIS];
	float target_joints[N_AXIS];

	// transform target to joint space
	inv_kin_slow(target_joints, target_pose, offset);
	
	
	// Calculate the buffer head after we push this byte
	int next_buffer_head = (motion_buffer_head + 1) % MOTION_BUFFER_SIZE;

	// If the buffer is full: good! That means we are well ahead of the robot.
	// Rest here until there is room in the buffer.
	while(motion_buffer_tail == next_buffer_head){};
	
    motion_block_t *block = &motion_buffer[motion_buffer_head];
    block -> max_step_count = 0;
    block -> millimeters = 0;
    block -> radians = 0;

    for(i=0;i<N_AXIS;i++){
        if (i == 3 || i == 4){
            target_steps[i] = lround(target_joints[i]*STEPS_PER_RADIAN) ; 
            block -> steps[i] = target_steps[i];
            block -> max_step_count = max(block->max_step_count,block->steps[i]);
            block -> radians += pow(abs(target_steps[i])/STEPS_PER_RADIAN,2);
        }else{
            target_steps[i] = lround(target_joints[i]*STEPS_PER_MM) ; 
            block -> steps[i] = target_steps[i];
            block -> max_step_count = max(block->max_step_count,block->steps[i]);
            block -> millimeters += pow(abs(target_steps[i])/STEPS_PER_MM,2);
        }

    }
    block -> millimeters = sqrt(block->millimeters);
    block -> radians = sqrt(block->radians);

    #if DEBUG
		printf("Steps: %d %d %d %d %d BufferHead: %d\nMillimeters: %f\nRadians: %f\n\n",block->steps[X_Axis],block->steps[Y_Axis],block->steps[Z_Axis],
			block->steps[A_Axis],block->steps[C_Axis],motion_buffer_head,block->millimeters,block->radians);
    #endif
    
	motion_buffer_head = next_buffer_head;
	
	ISR_enable();
}

motion_block_t *get_motion_block(){
    if (motion_buffer_head == motion_buffer_tail) { return(NULL); }
    return(&motion_buffer[motion_buffer_tail]);
}

inline void increment_current_block() {
	if (motion_buffer_head != motion_buffer_tail)
		motion_buffer_tail = (motion_buffer_tail + 1) % MOTION_BUFFER_SIZE;
}