#ifndef STEPPER_H_
#define STEPPER_H_

void ISR_init();
void ISR_enable();
void ISR_disable();
#endif