#ifndef parser_h
#define parser_h

// used to keep track of G-code inputs
typedef struct{
    /* for the sake of the project. The machine is also in absolute position mode.
       Only unit/min feedrate mode. For xyz mm/min. For AC rad/min. */ 
    float feedrate; //feedrate in units/min
    float ijklm[5]; // for offsets
    float xyzac[5]; // for target position
	
	//TODO Mcode Scode Pcode
	
	

}parser_input_t;
extern parser_input_t parser_input;

// used to keep track of state of machine
typedef struct{

    float feedrate; // current feedrate of the tool
    float position[5]; //current position of the tool 
    uint8_t plane[2]; // plane of curve motions. Default:XY
    uint8_t axis_linear; // linear axis for Helical motion

}parser_state_t;
extern parser_state_t parser_state;

//keep track of axis numbers
#define X_Axis 0
#define Y_Axis 1
#define Z_Axis 2
#define A_Axis 3
#define C_Axis 4


void parser_init();
void parse_line(char *line);

#endif