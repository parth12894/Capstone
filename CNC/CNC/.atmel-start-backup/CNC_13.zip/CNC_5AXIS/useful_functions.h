#ifndef useful_functions_h
#define useful_functions_h

float get_float_after_letter(char * str,uint8_t *char_counter);

#endif