#include "CNC_5Axis.h"

parser_input_t parser_input;
parser_state_t parser_state;

void parser_init(){
    memset(&parser_state,0,sizeof(parser_state_t));
    parser_state.plane[0] = X_Axis;
    parser_state.plane[1] = Y_Axis; // Default XY Plane
    parser_state.axis_linear = Z_Axis; 
}

/* 3-part interpreter
1. parsing
2. error checking
3. execution
*/

// parsing
void parse_line(char *line){
    // inputs = 0
    memset(&parser_input,0,sizeof(parser_input_t));
    
    //uint8_t axis_0, axis_1, axis_linear; //for G2/3
    uint8_t command = 255; // integer indicates G command ie. 2 -> G2

    uint8_t char_counter = 0;
    char letter;
	
    if(line[0] !='G'){
		printf("ERROR: Not G Command\n"); 
		return;
	}
	
    switch(line[1]){
        case '0':
			#if DEBUG
				printf("RAPID LINEAR MOVE\n");
            #endif
            command = 0;
            break;
        case '1':
             switch(line[2]){
                 case '7':
					#if DEBUG
						printf("Plane: XY\n");
                    #endif
                    command = 17;
                    break;
                 case '8':
					#if DEBUG
						printf("Plane: XZ\n");
                    #endif
					command = 18;
                    break;
                 case '9':
					#if DEBUG
						printf("Plane: YZ\n");
                    #endif
					command = 19;
                    break;
                 default:
					#if DEBUG
						printf("LINEAR MOVE\n");
                    #endif
					command = 1;
                    break;
             }
             break;
        case '2':
			#if DEBUG
				printf("CURVE/HELICAL MOVE CW\n");
            #endif
			command = 2;
            break;
        case '3':
			#if DEBUG
				printf("CURVE/HELICAL MOVE CCW\n");
			#endif
            command = 3;
            break;
        case '4':
			#if DEBUG
				printf("DWELLING\n");
			#endif
            command = 4;
            break;
        default:
            break;
    }

    while(line[char_counter] != 0){ // 0-terminated line
        char_counter++;
        letter = line[char_counter];

        // Once command is set, get parameter values
        switch(letter){
            case 'X':
                char_counter++;
                parser_input.xyzac[X_Axis] = get_float_after_letter(line,&char_counter);
                
            break;
            case 'Y':
                char_counter++;
                parser_input.xyzac[Y_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'Z':
                char_counter++;
                parser_input.xyzac[Z_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'A':
                char_counter++;
                parser_input.xyzac[A_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'C':
                char_counter++;
                parser_input.xyzac[C_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'I':
                char_counter++;
                parser_input.ijklm[X_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'J':
                char_counter++;
                parser_input.ijklm[Y_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'K':
                char_counter++;
                parser_input.ijklm[Z_Axis] = get_float_after_letter(line,&char_counter);
            break;
            case 'F':
                char_counter++;
                parser_input.feedrate = get_float_after_letter(line,&char_counter);
                parser_state.feedrate = parser_input.feedrate;
            break;
        }

    } 
    // Reserved for future error checking

    // Execution
    float input_relative[N_Axis];
    int i;
    switch(command){
        case 0:
            add_linear_motion(parser_input.xyzac, parser_state.position);
            memcpy(parser_state.position,parser_input.xyzac,N_Axis*sizeof(float));
            // ADD Code to indicate rapid move
            break;
        case 1:
            add_linear_motion(parser_input.xyzac, parser_state.position);
            memcpy(parser_state.position,parser_input.xyzac,N_Axis*sizeof(float));
            break;
        case 2:
            /* The target input is relative to the position. So we need to convert the absolute G command arguments
               to relative.*/
            for (i=0;i<N_Axis;i++){
                input_relative[i] = parser_input.xyzac[i] - parser_state.position[i];

            }

            #if DEBUG
            printf("relative position: %f %f %f %f %f\n\n", input_relative[X_Axis],input_relative[Y_Axis],input_relative[Z_Axis],
                input_relative[A_Axis],input_relative[C_Axis]);
            #endif

            add_arc_motion(parser_state.position,input_relative,parser_input.ijklm,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear,1);
            break;
        case 3:
            for (i=0;i<N_Axis;i++){
                input_relative[i] = parser_input.xyzac[i] - parser_state.position[i];

            }

            #if DEBUG
            printf("relative position: %f %f %f %f %f\n\n", input_relative[X_Axis],input_relative[Y_Axis],input_relative[Z_Axis],
                input_relative[A_Axis],input_relative[C_Axis]);
            #endif

            add_arc_motion(parser_state.position,input_relative,parser_input.ijklm,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear,0);
            break;
        case 4:
            //PUT DISABLE ISR CODE HERE FOR DWELLING
            break;
        case 17:
            parser_state.plane[0] = X_Axis;
            parser_state.plane[1] = Y_Axis;
            parser_state.axis_linear = Z_Axis;
            break;
        case 18:
            parser_state.plane[0] = X_Axis;
            parser_state.plane[1] = Z_Axis;
            parser_state.axis_linear = Y_Axis;
            break;
        case 19:
            parser_state.plane[0] = Y_Axis;
            parser_state.plane[1] = Z_Axis;
            parser_state.axis_linear = X_Axis;
            break;
        default:
			#if DEBUG
				printf("Nothing Happened!");
			#endif
            break;
    }
}




