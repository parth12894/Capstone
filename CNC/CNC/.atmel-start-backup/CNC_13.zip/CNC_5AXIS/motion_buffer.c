#include "CNC_5Axis.h"

static motion_block_t motion_buffer[motion_buffer_size];
static int motion_buffer_head ;

// unused 
typedef struct{
    uint32_t position[N_Axis]; // in steps
    float direction[N_Axis];
    float prev_speed;
} pos_info_t;
static pos_info_t pos;

void update_motion_buffer(float* target_pose, float* offset){

    int i;
    uint32_t target_steps[N_Axis];
	float target_joints[N_Axis];

	// transform target to joint space
	inv_kin_slow(target_joints, target_pose, offset);
 
    motion_block_t *block = &motion_buffer[motion_buffer_head];
    block -> step_count = 0;
    block -> millimeters = 0;
    block -> radians = 0;

    for(i=0;i<N_Axis;i++){
        if (i == 3 || i == 4){
            target_steps[i] = lround(target_joints[i]*steps_per_radian) ; 
            block -> steps[i] = target_steps[i];
            block -> step_count = max(block->step_count,block->steps[i]);
            block -> radians += pow(abs(target_steps[i])/steps_per_radian,2);
        }else{
            target_steps[i] = lround(target_joints[i]*steps_per_mm) ; 
            block -> steps[i] = target_steps[i];
            block -> step_count = max(block->step_count,block->steps[i]);
            block -> millimeters += pow(abs(target_steps[i])/steps_per_mm,2);
        }
    }
    block -> millimeters = sqrt(block->millimeters);
    block -> radians = sqrt(block->radians);

    #if DEBUG
		printf("Steps: %d %d %d %d %d BufferHead: %d\nMillimeters: %f\nRadians: %f\n\n",block->steps[X_Axis],block->steps[Y_Axis],block->steps[Z_Axis],
			block->steps[A_Axis],block->steps[C_Axis],motion_buffer_head,block->millimeters,block->radians);
    #endif
    
	motion_buffer_head++;
}

motion_block_t *get_motion_block(){
    return motion_buffer;
}