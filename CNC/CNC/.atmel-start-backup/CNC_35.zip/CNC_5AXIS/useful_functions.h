#ifndef USEFUL_FUNCTIONS_H_
#define USEFUL_FUNCTIONS_H_

float get_float_after_letter(char * str,uint8_t *char_counter);

void sanity_check();

#endif