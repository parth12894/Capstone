#ifndef FORWARD_KINEMATICS_H_
#define FORWARD_KINEMATICS_H_

float **for_kin_slow_AC(float A, float C);

#endif /* FORWARD_KINEMATICS_H_ */