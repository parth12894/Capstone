#include "CNC_5Axis.h"

float get_float_after_letter(char * str,uint8_t *char_counter){
    char float_str[9] = {0};
    uint8_t float_ctr = 0;
    
    while(str[*char_counter]!=' '&&str[*char_counter]!=0){
        float_str[float_ctr] = str[*char_counter];
        //if (str[*char_counter]=='.'){ 
            //float_ctr++;
            //*char_counter = *char_counter + 1;
            //float_str[float_ctr] = str[*char_counter];
            //break;}
        float_ctr++;
        *char_counter = *char_counter + 1;
    }
    
    return atof(float_str);
}

