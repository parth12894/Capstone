#include "CNC_5AXIS/CNC_5Axis.h"

#define X_DIR1 0x2000000 


char line[5][128] =
{	"G0 X0 Y0 F100",
	"G1 X1 Y0",
	"G1 X1 Y1",
	"G1 X0 Y1",
	"G0 X0 Y0"
};





/**
 * Example of using TIMER_0.
 */
static struct timer_task TIMER_0_task;

static void TIMER_0_task_cb(const struct timer_task *const timer_task)
{
}

void TIMER_0(void)
{
	TIMER_0_task.interval = 10;
	TIMER_0_task.cb       = TIMER_0_task_cb;
	TIMER_0_task.mode     = TIMER_TASK_REPEAT;


	timer_add_task(&TIMER_0, &TIMER_0_task);
	timer_start(&TIMER_0);
}



int main()
{
	atmel_start_init();
	TIMER_0();
	
	for(;;)
	{
		delay_ms(1000);
		printf("");
		
	}
	
	while(1);
	
	
};





//
//int main()
//{
	//atmel_start_init();
	//parser_init();
	//stepper_init();
	//parse_line("M9");
//
	//printf("\n\t\t--  PP01 - 3+2 Axis CNC Controller  --\n");
	//printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__);
	//ISR_EN();
	//
	//
	//uint32_t temp;
	//
	////printf("====================Sanity Check=====================\n");
	////uint8_t i;
	////for(i=0;i<5;i++)
	////{
		////printf(">> Command: ");
		////
		////puts(line[i]);
		////parse_line(line[i]);
		////
		////delay_ms(3000);
	////}
	////printf("================Sanity Check Complete================\n");
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//gpio_set_pin_function(Q3, GPIO_PIN_FUNCTION_OFF);
	//gpio_set_pin_direction(Q4, GPIO_DIRECTION_OUT);
	//gpio_set_pin_function(Q4, GPIO_PIN_FUNCTION_OFF);
	//
	////gpio_set_pin_function(Q5, GPIO_PIN_FUNCTION_OFF);
	////gpio_set_pin_function(Q6, GPIO_PIN_FUNCTION_OFF);
//////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
	//char input[128];
	//while(1)
	//{
		//printf("\n>> ");
		////printf("ok\r\n");
		//fgets(input, sizeof(input), stdin);
		//printf("%s",input);
		//parse_line(input);
		//
		//#if DEBUG
			//printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],parser_input.ijklm[0],parser_input.ijklm[1],parser_input.ijklm[2],parser_input.feedrate);
			//printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %f\nPlane: %d %d\nVertical: %d\n\n",parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		//#endif
	//}
	//
	//
	//for(;;);
	//while (1);
	//
//}
//
//





/*

for xyz
1/32 micro stepping -> fastest X step time 15*2 = 30 us
1/16 micro stepping -> fastest X step time 27*2 = 54 us

*/










