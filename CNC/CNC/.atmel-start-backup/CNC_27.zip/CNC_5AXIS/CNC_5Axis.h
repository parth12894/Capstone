#ifndef CNC_5Axis_h
#define	CNC_5Axis_h


// Debugging
//#ifndef DEBUG
	#define DEBUG 1
//#endif
#define DEBUG_ISR 0
#define RUN_MOTORS 1


// Globals Parameters
#define STEPPER_ISR_INTERVAL 4
#define N_AXIS 5
#define STEPS_PER_MM_X 1280.0
#define STEPS_PER_MM_Y 1280.0
#define STEPS_PER_MM_Z 800.0
#define STEPS_PER_DEGREE 4074.366506			//71.111111111 STEPS/DEGREE			// 4074.366506 steps/radian
#define INCHES_PER_MM 25.4 
#define MOTION_BUFFER_SIZE 512
#define PI 3.14158265358979323846

#define TOTAL_SECANT_ERROR 0.005
#define ERROR_CORRECTION_COUNT 5
#define MINIMUM_SEGMENTS 10


// Fast math
#ifndef sign
    #define sign(x) ((x>=0)-(x<0))
#endif

#ifndef square
	#define square(x) (x*x)
#endif



// Useful names
#define HIGH true
#define LOW false

#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2
#define A_AXIS 3
#define C_AXIS 4


// C Libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <string.h>

//Project Libraries
#include "inv_kin.h"
#include "motion_buffer.h"
#include "motion_control.h"
#include "parser.h"
#include "useful_functions.h"
#include "pin_define.h"
#include "stepper.h"
#include "filesystem.h"

//Atmel Libraries
#include <atmel_start.h>
#include <diskio.h>
#include <ff.h>
#include <sd_mmc.h>
#include <sd_mmc_protocol.h>


#endif


