#ifndef motion_buffer_h
#define motion_buffer_h

typedef struct{
	
	// Used for stepper control
	uint32_t steps[N_AXIS];
	uint32_t max_step_count;
	
	
	uint8_t dir[N_AXIS];
	uint8_t is_Mcode;
	uint8_t code;
	uint32_t speed;
	uint32_t parameter;
	
	#if DEBUG_ISR
		uint32_t bufferhead;
	#endif
	
	// Used for acceleration
	//float start_speed;
	//float max_start_speed;
	//float flat_speed;
	//float acceleration;
	float millimeters;
	float radians;
}motion_block_t;

static motion_block_t motion_buffer[MOTION_BUFFER_SIZE];


/*Adds a linear motion block to the head of the motion buffer*/
void update_motion_buffer(float* target, float*offset);
motion_block_t *get_motion_block();

void increment_current_block();	

void add_M_block(uint8_t code, uint32_t speed, uint32_t parameter);

void increment_current_block();


int get_head();
int get_tail();

#endif