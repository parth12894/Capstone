#ifndef CNC_5Axis_h
#define	CNC_5Axis_h


// Debugging
#define DEBUG 1
#define DEBUG_ISR 0
#define RUN_MOTORS 1


// Globals Parameters
#define N_AXIS 5
#define STEPS_PER_MM 640.0
#define STEPS_PER_DEGREE 8.8888
#define MOTION_BUFFER_SIZE 512
#define PI 3.14158265358979323846
#define TOTAL_SECANT_ERROR 0.005
#define ERROR_CORRECTION_COUNT 5
#define MINIMUM_SEGMENTS 10


// Fast math
#ifndef sign
    #define sign(x) ((x>=0)-(x<0))
#endif

#ifndef square
	#define square(x) (x*x)
#endif



// Useful names
#define HIGH true
#define LOW false

#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2
#define A_AXIS 3
#define C_AXIS 4


// C Libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <string.h>

//Project Libraries
#include "inv_kin.h"
#include "motion_buffer.h"
#include "motion_control.h"
#include "parser.h"
#include "useful_functions.h"
#include "pin_define.h"
#include "stepper.h"
#include "filesystem.h"

//Atmel Libraries
#include <atmel_start.h>
#include <diskio.h>
#include <ff.h>
#include <sd_mmc.h>
#include <sd_mmc_protocol.h>


#endif


