#ifndef STEPPER_H_
#define STEPPER_H_



#define ISR_EN() timer_start(&TIMER_1);
#define ISR_Dis() timer_stop(&TIMER_1);

void ISR_init();

static inline void ISR_enable();

static inline void ISR_disable();

void stepper_init();
#endif