#include "CNC_5Axis.h"

int main_test ()
{

	#if DEBUG_FILE
		//reset files
		FILE *fp1,*fp2,*fp3,*fp4,*fp5;
		fp1 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\xsegments.txt","w");
		fp2 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\ysegments.txt","w");
		fp3 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\zsegments.txt","w");
		fp4 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\asegments.txt","w");
		fp5 = fopen("C:\\Users\\Jason\\Downloads\\5AxisCNC\\cegments.txt","w");
		fclose(fp1);
		fclose(fp2);
		fclose(fp3);
		fclose(fp4);
		fclose(fp5);
	#endif

	char line[128];
	parser_init();
	while(1){
		
		#if DEBUG_FILE
			printf("Enter Something: \n");
		#endif
		
		fgets(line, sizeof(line), stdin);
		parse_line(line);
		
		#if DEBUG_FILE
			printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",
					parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],
					parser_input.ijklm[0],parser_input.ijklm[1],parser_input.ijklm[2],
					parser_input.feedrate);

			printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %f\nPlane: %d %d\nVertical: %d\n\n",
					parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],
					parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		#endif
	}

    return (EXIT_SUCCESS);
}


