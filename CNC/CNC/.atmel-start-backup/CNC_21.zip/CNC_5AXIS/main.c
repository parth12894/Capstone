#include "CNC_5AXIS/CNC_5Axis.h"

#define X_DIR1 0x2000000 



int main()
{
	atmel_start_init();
	uint8_t i;
	for(i=0;i<10;i++)
		printf("\n\n\n");
		
	printf("\t\t--  PP01 - 5 Axis CNC Controller  --\n");
	printf("\t\t-- Compiled: %s %s --\n\r", __DATE__, __TIME__); 
	

	//delay_ms(1000);

	
	parser_init();
	
	ISR_init();


	while (1);
}








