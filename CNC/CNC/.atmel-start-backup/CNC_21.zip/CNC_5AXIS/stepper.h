#ifndef STEPPER_H_
#define STEPPER_H_

void ISR_init();

inline void ISR_enable();

inline void ISR_disable();

#endif