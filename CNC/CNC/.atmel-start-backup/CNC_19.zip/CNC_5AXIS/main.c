#include "CNC_5AXIS/CNC_5Axis.h"


//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define X_DIR1 0x2000000 

int main()
{
	atmel_start_init();
	
	printf("--  PP01 - 5 Axis CNC Controller  --\n");
	printf("-- Compiled: %s %s --\n\r", __DATE__, __TIME__); 
	

	delay_ms(1000);
	
	
	
	ISR_init();
	timer_start(&TIMER_0);
	
	
	//parser_init();
	//printf("----\n");
	//
	//
	//char line[128];
	//while(1){
		//
		//
		//printf("Enter Something: \n");
		//
		//
		//fgets(line, sizeof(line), stdin);
		//parse_line(line);
		//
		//
		//printf("Parameters:\n X%f Y%f Z%f A%f C%f I%f J%f K%f\nFeedrate: %f\n\n",
		//parser_input.xyzac[0],parser_input.xyzac[1],parser_input.xyzac[2],parser_input.xyzac[3],parser_input.xyzac[4],
		//parser_input.ijklm[0],parser_input.ijklm[1],parser_input.ijklm[2],
		//parser_input.feedrate);
//
		//printf("State:\nPosition: X%f Y%f Z%f A%f C%f\nFeedrate: %f\nPlane: %d %d\nVertical: %d\n\n",
		//parser_state.position[0],parser_state.position[1],parser_state.position[2],parser_state.position[3],parser_state.position[4],
		//parser_state.feedrate,parser_state.plane[0],parser_state.plane[1],parser_state.axis_linear);
		//
	//}



	


	while (1);
}








